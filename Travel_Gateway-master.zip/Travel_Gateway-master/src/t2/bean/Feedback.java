package t2.bean;

public class Feedback {
	String customer_visit;
	public String getCustomer_visit() {
		return customer_visit;
	}
	public void setCustomer_visit(String customer_visit) {
		this.customer_visit = customer_visit;
	}
	public String getCustomer_reason() {
		return customer_reason;
	}
	public void setCustomer_reason(String customer_reason) {
		this.customer_reason = customer_reason;
	}
	public String getCustomer_need() {
		return customer_need;
	}
	public void setCustomer_need(String customer_need) {
		this.customer_need = customer_need;
	}
	public String getCustomer_improve() {
		return customer_improve;
	}
	public void setCustomer_improve(String customer_improve) {
		this.customer_improve = customer_improve;
	}
	public String getCustomer_easy() {
		return customer_easy;
	}
	public void setCustomer_easy(String customer_easy) {
		this.customer_easy = customer_easy;
	}
	String customer_reason;
	String customer_need;
	String customer_improve;
	String customer_easy;

}
