package t2.bean;
import t2.controllers.*;

public class VendorRegistrationBean {
	String vendorusername ;
	 String firstname ;
	 String lastname ;
	 String businessname ;
	 String businesstype ;
	 String businessregistrationnumber ;
	 int ssn ;
	 String vendoremail ;
	 String vendorpassword ;
	 String vendorcontact;
	 String vendoraddress ;
	 String vendorcity ;
	 String vendorstate ;
	 int vendorstatus;
	 int vendorid;
	public int getVendorid() {
		return vendorid;
	}
	public void setVendorid(int vendorid) {
		this.vendorid = vendorid;
	}
	public int getVendorstatus() {
		return vendorstatus;
	}
	public void setVendorstatus(int vendorstatus) {
		this.vendorstatus = vendorstatus;
	}
	public String getVendorusername() {
		return vendorusername;
	}
	public void setVendorusername(String vendorusername) {
		this.vendorusername = vendorusername;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getBusinessname() {
		return businessname;
	}
	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}
	public String getBusinesstype() {
		return businesstype;
	}
	public void setBusinesstype(String businesstype) {
		this.businesstype = businesstype;
	}
	public String getBusinessregistrationnumber() {
		return businessregistrationnumber;
	}
	public void setBusinessregistrationnumber(String businessregistrationnumber) {
		this.businessregistrationnumber = businessregistrationnumber;
	}
	public int getSsn() {
		return ssn;
	}
	public void setSsn(int ssn2) {
		this.ssn = ssn2;
	}
	public String getVendoremail() {
		return vendoremail;
	}
	public void setVendoremail(String vendoremail) {
		this.vendoremail = vendoremail;
	}
	public String getVendorpassword() {
		return vendorpassword;
	}
	public void setVendorpassword(String vendorpassword) {
		this.vendorpassword = vendorpassword;
	}
	public String getVendorcontact() {
		return vendorcontact;
	}
	public void setVendorcontact(String vendorcontact) {
		this.vendorcontact = vendorcontact;
	}
	public String getVendoraddress() {
		return vendoraddress;
	}
	public void setVendoraddress(String vendoraddress) {
		this.vendoraddress = vendoraddress;
	}
	public String getVendorcity() {
		return vendorcity;
	}
	public void setVendorcity(String vendorcity) {
		this.vendorcity = vendorcity;
	}
	public String getVendorstate() {
		return vendorstate;
	}
	public void setVendorstate(String vendorstate) {
		this.vendorstate = vendorstate;
	}

}
